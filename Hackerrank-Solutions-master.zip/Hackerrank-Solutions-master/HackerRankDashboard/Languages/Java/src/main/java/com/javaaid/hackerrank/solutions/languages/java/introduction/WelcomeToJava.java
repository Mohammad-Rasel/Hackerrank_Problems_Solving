package com.javaaid.hackerrank.solutions.languages.java.introduction;

/**
 * 
 * @author Kanahaiya Gupta
 *
 */
public class WelcomeToJava {

	public static void main(String[] args) {
		System.out.println("Hello, World.");
		System.out.println("Hello, Java.");

	}
}
