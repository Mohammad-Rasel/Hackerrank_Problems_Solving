/**
 * 
 */
package com.javaaid.hackerrank.solutions.languages.java.introduction;

/**
 * @author Kanahaiya Gupta
 *
 */
public class JavaIntToString {
	int n; //already decalared
	String s=n+"";
}
